//
//  FastViewController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/12.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "FastViewController.h"

@interface FastViewController ()<UIWebViewDelegate>
@property (nonatomic, strong) UIWebView *webView1;
@property (nonatomic, strong) UIWebView *webView2;
@end

@implementation FastViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.webView1];
    [self.view addSubview:self.webView2];
    
}


- (UIWebView *)webView1 {
    if (_webView1 == nil) {
        _webView1 = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight/2.0)];
        _webView1.scalesPageToFit = YES;
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"fastY" withExtension:@"html"];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [_webView1 loadRequest:request];
        _webView1.delegate = self;
    }
    
    return _webView1;
}

- (UIWebView *)webView2 {
    if (_webView2 == nil) {
        _webView2 = [[UIWebView alloc] initWithFrame:
                     CGRectMake(0, kScreenHeight/2.0,kScreenWidth, kScreenHeight/2.0)];
        _webView2.scalesPageToFit = YES;
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"fastN" withExtension:@"html"];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [_webView2 loadRequest:request];
        _webView2.delegate = self;
    }
    
    return _webView2;
}


@end
