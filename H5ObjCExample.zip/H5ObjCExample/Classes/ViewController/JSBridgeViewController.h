//
//  JSBridgeViewController.h
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/9.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface JSBridgeViewController : BaseViewController

@end
