//
//  H5AnimationController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/12.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "H5AnimationController.h"
#import <WebKit/WebKit.h>

@interface H5AnimationController () <UIWebViewDelegate,WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate>
@property (nonatomic, strong) UIWebView *webView;


@property (nonatomic, strong) WKWebView *wkWebView;
@property (nonatomic, strong) UIProgressView *progressView;

@end

@implementation H5AnimationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.progressView];
    
//    [self.view addSubview:self.webView];
     [self.view addSubview:self.wkWebView];
}


- (UIWebView *)webView {
    if (_webView == nil) {
        _webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
        _webView.scalesPageToFit = YES;
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"animation" withExtension:@"html"];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [_webView loadRequest:request];
        _webView.delegate = self;
    }
    
    return _webView;
}




- (WKWebView *)wkWebView {
    if (_wkWebView == nil) {
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
        
        // 设置偏好设置
        config.preferences = [[WKPreferences alloc] init];
        // 默认为0
        config.preferences.minimumFontSize = 10;
        // 默认认为YES
        config.preferences.javaScriptEnabled = YES;
        // 在iOS上默认为NO，表示不能自动通过窗口打开
        config.preferences.javaScriptCanOpenWindowsAutomatically = YES;
        
        // web内容处理池
        config.processPool = [[WKProcessPool alloc] init];
        
        // 通过JS与webview内容交互
        config.userContentController = [[WKUserContentController alloc] init];
        
        // 我们可以在WKScriptMessageHandler代理中接收到
        [config.userContentController addScriptMessageHandler:self name:@"AppModel"];
        
        // 添加一个JS到HTML中，这样就可以直接在JS中调用我们添加的JS方法
        WKUserScript *script = [[WKUserScript alloc]initWithSource:@"function showAlert() { alert('在载入webview时通过Swift注入的JS方法');"
                                                     injectionTime:WKUserScriptInjectionTimeAtDocumentStart
                                                  forMainFrameOnly:YES];
        [config.userContentController addUserScript:script];
        
        
        _wkWebView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
        NSURL *path = [[NSBundle mainBundle] URLForResource:@"animation" withExtension:@"html"];
        [_wkWebView loadRequest:[NSURLRequest requestWithURL:path]];
       
        // 导航代理
        _wkWebView.navigationDelegate = self;
        // 与webview UI交互代理
        _wkWebView.UIDelegate = self;
        
        // 添加KVO监听
        [_wkWebView addObserver:self
                         forKeyPath:@"loading"
                            options:NSKeyValueObservingOptionNew
                            context:nil];
        [_wkWebView addObserver:self
                         forKeyPath:@"title"
                            options:NSKeyValueObservingOptionNew
                            context:nil];
        [_wkWebView addObserver:self
                         forKeyPath:@"estimatedProgress"
                            options:NSKeyValueObservingOptionNew
                            context:nil];
        
      
    }
    return _wkWebView;
}


- (UIProgressView *)progressView {
    if (_progressView == nil) {
        // 添加进入条
        _progressView = [[UIProgressView alloc] init];
        _progressView.frame = self.view.bounds;
        
        _progressView.backgroundColor = [UIColor redColor];
    }
    return _progressView;
}

#pragma mark - WKScriptMessageHandler【jsCallOC 交互的关键】
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    if ([message.name isEqualToString:@"AppModel"]) {
        // 打印所传过来的参数，只支持NSNumber, NSString, NSDate, NSArray,
        // NSDictionary, and NSNull类型
        NSLog(@"🍎didReceiveScriptMessage：%@", message.body);
    }
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary<NSString *,id> *)change
                       context:(void *)context {
    if ([keyPath isEqualToString:@"loading"]) {
        NSLog(@"loading");
        
    } else if ([keyPath isEqualToString:@"title"]) {
        self.title = self.wkWebView.title;
        
    } else if ([keyPath isEqualToString:@"estimatedProgress"]) {
        NSLog(@"progress: %f", self.wkWebView.estimatedProgress);
        self.progressView.progress = self.wkWebView.estimatedProgress;
    }
    
    // 加载完成
    if (!self.wkWebView.loading) {
        [UIView animateWithDuration:0.5 animations:^{
            self.progressView.alpha = 0;
        }];
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
