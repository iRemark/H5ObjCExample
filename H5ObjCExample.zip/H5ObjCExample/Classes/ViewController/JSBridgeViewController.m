//
//  JSBridgeViewController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/9.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "JSBridgeViewController.h"

@interface JSBridgeViewController () <UIWebViewDelegate>
@property WebViewJavascriptBridge *bridge;
@property (nonatomic, strong) UIWebView *webView;

@end

@implementation JSBridgeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:webView];
    self.webView = webView;
    
    NSString *htmlPath = [[NSBundle mainBundle] pathForResource:@"JavascriptBridge" ofType:@"html"];
    NSString *appHtml = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
    NSURL *baseURL = [NSURL fileURLWithPath:htmlPath];
    [webView loadHTMLString:appHtml baseURL:baseURL];
    
    
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"reload" style:UIBarButtonItemStyleDone target:self.webView action:@selector(reload)];
    
    self.navigationItem.rightBarButtonItem = item;
    
    
    [self createButtons];
    
    
    
    // 开启日志
    [WebViewJavascriptBridge enableLogging];

    self.bridge = [WebViewJavascriptBridge bridgeForWebView:webView];
    [self.bridge setWebViewDelegate:self];
    
    
    /** jsCallOC **/
    [self.bridge registerHandler:@"jsCallOC" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSLog(@"jsCallOC_oc %@", data);
        
        if (responseCallback) {
            responseCallback(@{@"title": @"jsCallOC_oc"});
        }
    }];
    
    [self.bridge registerHandler:@"jsCallOC2" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSLog(@"jsCallOC2_oc %@", data);
        
        if (responseCallback) {
            responseCallback(@{@"title": @"jsCallOC2_oc"});
        }
    }];
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    NSLog(@"webViewDidStartLoad");
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    NSLog(@"webViewDidFinishLoad");
}



- (void)createButtons {
    NSArray *array = @[@"ocCallJS",
                       @"ocCallJSAndJSCallBack",
                       //@"ocCallJSWithTitle:message",
                       //@"ocCallJSWithDictionary",
                       //@"ocCallJSWithArray"
                       ];
    
    NSInteger index = 0;
    for (NSString *string in array) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [button setTitle:string forState:UIControlStateNormal];
        [button addTarget:self action:@selector(buttonAciton:) forControlEvents:UIControlEventTouchUpInside];
        
        button.frame = CGRectMake(kScreenWidth-300, 100+(index * 50), 280, 30);
        
        button.layer.borderColor = [UIColor redColor].CGColor;
        button.layer.borderWidth = 1;
        button.layer.cornerRadius = 3;
        
        index ++;
        
        [self.view addSubview:button];
    }
}


/** ocCallJS **/
- (void)buttonAciton:(UIButton *)button {
    if ([button.currentTitle isEqualToString:@"ocCallJS"]) {

        [self.bridge callHandler:@"ocCallJS" data:nil responseCallback:^(id responseData) {
            NSLog(@"ocCallJS_oc:%@",responseData);
        }];
        
        
    }else if ([button.currentTitle isEqualToString:@"ocCallJSAndJSCallBack"]) {
        [self.bridge callHandler:@"ocCallJSWithDictionary"
                            data:@{@"title": @"myoctitle",@"message":@"myocmessage"}
                responseCallback:^(id responseData) {
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"ocCallJSWithDictionary" message:@"ocCallJS 然后js回调了" delegate:nil cancelButtonTitle:@"I know" otherButtonTitles:nil];
                        [alert show];
                    });
                    
                    
                    NSLog(@"ocCallJSWithDictionary_oc: %@", responseData);
                }];
    }
}

@end


