//
//  CallEachViewController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/8.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "WebViewController.h"
#import "WebViewModel.h"

@interface WebViewController () <UIWebViewDelegate>

@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, strong) JSContext *jsContext;

@property (nonatomic, strong) WebViewModel *model;
@end

@implementation WebViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.webView];
    [self createButtons];
    
    
    /** 下面是 调用 js 较为粗暴的一些方式：不利于维护扩展 **/
    
    /** 方式一： **/
    //一个JSContext:语境 上下文，就类似于Js中的window，只需要创建一次即可。
    self.jsContext = [[JSContext alloc] init];
    
    // jscontext可以直接执行JS代码。
    [self.jsContext evaluateScript:@"var func1 = function(a) { return a * a }"];
    
    [self.jsContext evaluateScript:@"var num = 10"];
    JSValue *square = [self.jsContext evaluateScript:@"func1(num)"];
    NSLog(@"%@", square.toNumber);
    
    
    /** 方式二： **/
    JSValue *func1 = self.jsContext[@"func1"];
    JSValue *value1 = [func1 callWithArguments:@[@"20"]];
    NSLog(@"%@", value1.toNumber);
    
    
}

- (void)createButtons {
    NSArray *array = @[@"ocCallJS",
                       @"ocCallJSWithString",
                       //@"ocCallJSWithTitle:message",
                       //@"ocCallJSWithDictionary",
                       //@"ocCallJSWithArray"
                       ];
    
    NSInteger index = 0;
    for (NSString *string in array) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [button setTitle:string forState:UIControlStateNormal];
        [button addTarget:self action:@selector(buttonAciton:) forControlEvents:UIControlEventTouchUpInside];
        
        button.frame = CGRectMake(kScreenWidth-300, 100+(index * 50), 280, 30);
        
        button.layer.borderColor = [UIColor redColor].CGColor;
        button.layer.borderWidth = 1;
        button.layer.cornerRadius = 3;
        
        index ++;
        
        [self.view addSubview:button];
    }
}


- (void)buttonAciton:(UIButton *)button {
    if ([button.currentTitle isEqualToString:@"ocCallJS"]) {
        [self.model ocCallJS];
        
    }else if ([button.currentTitle isEqualToString:@"ocCallJSWithString"]) {
        [self.model ocCallJSWithString:@"myocString"];
        
    }else if ([button.currentTitle isEqualToString:@"ocCallJSWithTitle:message"]) {
//        [self.model ocCallJSWithString];
        
    }else if ([button.currentTitle isEqualToString:@"ocCallJSWithDictionary"]) {
        [self.model ocCallJSWithDictionary:@{@"title":@"myoctitle",@"message":@"myocmessage"}];
        
    }else if ([button.currentTitle isEqualToString:@"ocCallJSWithArray"]) {
        [self.model ocCallJSWithArray:@[@"myoctitle",@"myocmessage",@"30"]];
        
    }
}


- (UIWebView *)webView {
    if (_webView == nil) {
        _webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
        
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"callEach" withExtension:@"html"];
        [_webView loadRequest:[NSURLRequest requestWithURL:url]];
        
        //忽略web页面与_WebView组件的大小关系如果设置为YES可以执行缩放，但是web页面加载出来的时候，就会缩小到UIWebView组件的大小
        _webView.scalesPageToFit = NO;
        _webView.delegate = self;
    }
    
    return _webView;
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    self.jsContext = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    
    WebViewModel *model  = [[WebViewModel alloc] init];
    self.jsContext[@"CallEachModel"] = model;
    model.jsContext = self.jsContext;
    model.webView = self.webView;
    model.currentVC = self;
    self.model = model;
    
    self.jsContext.exceptionHandler = ^(JSContext *context, JSValue *exceptionValue) {
        context.exception = exceptionValue;
        NSLog(@"异常信息：%@", exceptionValue);
    };
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    
}

@end
