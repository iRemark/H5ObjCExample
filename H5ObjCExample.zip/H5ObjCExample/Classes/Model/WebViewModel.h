//
//  CallEachModel.h
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/8.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol WebViewJSExport <JSExport>

/** 遵守了 协议后 这些方法就暴露给 js 调用 **/


/** jsCallOC **/
- (void)jsCallOC;
- (void)jsCallOCWithString:(NSString *)string;

//js调用时候取函数名就好了 不要冒号 jsCallOCWithTitleMessage
- (void)jsCallOCWithTitle:(NSString *)title message:(NSString *)msg;

- (void)jsCallOCWithDictionary:(NSDictionary *)dictionary;
- (void)jsCallOCWithArray:(NSArray *)array;



/** ocCallJS **/
- (void)ocCallJS;
- (void)ocCallJSWithString:(NSString *)string;
- (void)ocCallJSWithTitle:(NSString *)title message:(NSString *)message;

- (void)ocCallJSWithDictionary:(NSDictionary *)dictionary;
- (void)ocCallJSWithArray:(NSArray *)array;


/** callEach **/
- (void)jsCallOCAndOCCallJSWithParams:(NSDictionary *)params;
- (void)ocCallJSAndJSCallOCWithParams:(NSDictionary *)params;


@end


@class BaseViewController;
@interface WebViewModel : NSObject <WebViewJSExport>

@property (nonatomic, weak) JSContext *jsContext;
@property (nonatomic, weak) UIWebView *webView;

@property (nonatomic, weak) BaseViewController *currentVC;

@end
