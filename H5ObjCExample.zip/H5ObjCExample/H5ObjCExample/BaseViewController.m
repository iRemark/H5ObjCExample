//
//  BaseViewController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/8.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "BaseViewController.h"


@interface BaseViewController ()
@property (nonatomic, strong) UIToolbar *topBar;

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)createTopView {
    
    UIToolbar *topBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 60)];
    topBar.backgroundColor = [UIColor greenColor];
    
    UILabel *tintLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, 80, 40)];
    tintLabel.textAlignment = NSTextAlignmentRight;
    tintLabel.text = @"请输入：";
    [topBar addSubview:tintLabel];
    
    UITextField *field = [[UITextField alloc]initWithFrame:CGRectMake(100, 10, 300, 40)];
    field.borderStyle = UITextBorderStyleRoundedRect;
    [topBar addSubview:field];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitle:@"确定" forState:UIControlStateNormal];
    
    button.frame = CGRectMake(400, 10, 60, 40);
    [button addTarget:self action:@selector(topButtonAciton:) forControlEvents:UIControlEventTouchUpInside];
    [topBar addSubview:button];
    
    
    [self.view addSubview:topBar];
    
    [UIView animateWithDuration:0.5 animations:^{
        topBar.frame = CGRectMake(0, 64, kScreenWidth, 60);
        
    }completion:^(BOOL finished) {
        
        if (self.topBar) {
            [self.topBar removeFromSuperview];
        }
        
        self.topBar = topBar;
       
    }];
    
    self.field = field;
}


- (void)topButtonAciton:(id)sender {
    [UIView animateWithDuration:0.5 animations:^{
        self.topBar.frame = CGRectMake(0, 0, kScreenWidth, 60);
        
    }completion:^(BOOL finished) {
        [self.topBar removeFromSuperview];
        
        if (self.block) {
            self.block(self.field.text);
        }
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
